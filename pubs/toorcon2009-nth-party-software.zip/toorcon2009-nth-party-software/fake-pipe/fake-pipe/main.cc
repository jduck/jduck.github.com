#include <Windows.h>
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

//
#define BS 0x10000

#pragma pack(1)

//
#define CONTROL_PIPE_NAME "\\\\.\\pipe\\Arzn_AdDocR1_Control"
#define PIPE_NUM 1
#define TRANSFER_PIPE_NAME "\\\\.\\pipe\\Arzn_AdDocR1_Transfer"

// from md5.c
extern "C" {
	char * MD_ascii(unsigned char [16]);
	char * MDString(char *);
	char * MDFile(char *);
};


// header for requests
typedef struct req_hdr {
	DWORD	len;
	BYTE	op;
}req_hdr_t;

//ascii names for client opcodes
char *cops[] = {
	"", "Client ready for requests", "", "", "", "Give me the file contents",
	"", "", "", "Ready for XML on transfer pipe", "Done with conversion",
	"Here is the converted attachment"
};

//server states
enum {
	WAIT_FOR_CLIENT, WAIT_FOR_TRANSPIPE_CONNECTION,
	SENT_XML, SENT_FILE, RECV_CONVERTED_FILE,
	DONE
};

//from client response 0xa
#define CONVERSION_SUCCESSFUL 0
#define CONVERSION_FAILED 1

// server opcodes
enum {
	SERVER_SEND_TPIPENAME = 7, SRV_SEND_XML = 3, SRV_SEND_FILE = 6,
};

//
char *ppt_procid = "8DA5A628-7DE1-46D0-9369-99EB65A70F8B";
char *jpg_procid = "80FD5D08-FD4B-48D3-9F1F-D6F53C4C8561";

//format of the XML description of the attachment
char *xml_msg =
"<BBASCMD><CD>NEXT</CD>"
"<CP><FileName>FileName</FileName>"
//
"<FileSize>%d</FileSize>"
"<CHINT>0</CHINT><DCS>64000</DCS><DT>2</DT><FTR>1</FTR><PARTIDX>999</PARTIDX>"
"<VER>4.12</VER><XCS>16000</XCS><XDI>320x240x16</XDI><DeviceType>1</DeviceType>"
"<FileFormat>%d</FileFormat><Fragment></Fragment><FragmentDOMID></FragmentDOMID>"
//
"<LoadingChunk>1</LoadingChunk><MD5>%s</MD5><OriginKey>BESAdmin@xchg2k3.idrl</OriginKey>"
//
"<OriginalDocumentName>%s</OriginalDocumentName>"
"<ProcID>%s</ProcID>"
//
"<ResponseRequire>1</ResponseRequire><TransID>%d</TransID>"
"</CP></BBASCMD>";

//output
bool silent = false;

/////////////////////////////
/////////////////////////////


//
void die(char *fmt, ...)
{
    DWORD   lastErr;
    va_list args;
    char    errbuf[0x1000];

    lastErr = GetLastError();

    va_start(args, fmt);
    vsnprintf_s(errbuf, sizeof(errbuf), _TRUNCATE, fmt, args);
    fprintf(stderr, "%s: GetLastError() = %u\n", errbuf, lastErr);
	fflush(stderr);
    va_end(args);

	exit(EXIT_FAILURE);
}


void info(char *fmt, ...)
{
    va_list args;

	if(!silent){
		va_start(args, fmt);
		vprintf(fmt, args);
		va_end(args);
	}
}

//
void hexdump(unsigned char *data, unsigned int amount, size_t addr)
{ /* from kernsh project */
  unsigned int dp;
  unsigned int p;
  const char trans[] =
  "................................ !\"#$%&'()*+,-./0123456789"
  ":;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklm"
  "nopqrstuvwxyz{|}~...................................."
  "....................................................."
  "........................................";
  
  for (dp = 1; dp <= amount; dp++) {
        if ((dp % 16) == 1) {
            fprintf(stdout, "    %#08x | ", addr+dp-1);
        }

        fprintf(stdout, "%02x ", data[dp-1]);
        if ((dp % 8) == 0 && (dp % 16) != 0) {
            fputs(" ", stdout);
        }
        if ((dp % 16) == 0) {
            fputs("| ", stdout);
            p = dp;
            for (dp -= 16; dp < p; dp++) {
                fprintf(stdout, "%c", trans[data[dp]]);
            }
            fputs("\n", stdout);
        }
    }
  
  if ((amount % 16) != 0) {
    p = dp = 16 - (amount % 16);
    for (dp = p; dp > 0; dp--) {
      fputs("   ", stdout);
      if (((dp % 8) == 0) && (p != 8)) {
        fputs(" ", stdout);
      }
    }
    fputs("| ", stdout);
    for (dp = (amount - (16 - p)); dp < amount; dp++) {
      fprintf(stdout, "%c", trans[data[dp]]);
    }
  }

  fputs("\n\n", stdout);
  
  fflush(NULL);
}

//
HANDLE create_pipe(char *name)
{
	HANDLE	h;

	h = CreateNamedPipeA(name, PIPE_ACCESS_DUPLEX,
				PIPE_TYPE_BYTE|PIPE_WAIT, PIPE_UNLIMITED_INSTANCES,
				BS, BS, 0, NULL);

	if(h == INVALID_HANDLE_VALUE)
		die("CreateNamedPipeA(%s)", name);
		
	info("\n[o]Created pipe %s (%p)\n\n", name, h);

	return h;
}

//
void connect_pipe(HANDLE pipe)
{
	//connnect client
	info("[o]Waiting for connection on pipe %p\n", pipe);
	if(!ConnectNamedPipe(pipe, NULL))
		die("ConnectNamedPipe(%p)", pipe);
	
	info("[oo]Connected pipe (%p)\n\n", pipe);
}

//
void write_req(HANDLE pipe, BYTE op, void *dat, DWORD datlen)
{
	req_hdr_t	hdr;
	DWORD	nwrote;

	hdr.op = op;
	hdr.len = 1 + datlen;

	if(!WriteFile(pipe, &hdr, sizeof(hdr), &nwrote, NULL))
		die("WriteFile(): reqhdr");

	if(nwrote != sizeof(hdr))
		die("WriteFile(): only wrote %u/%u of header", nwrote, sizeof(hdr));

	if(dat != NULL && datlen > 0){
		if(!WriteFile(pipe, dat, datlen, &nwrote, NULL))
			die("WriteFile(): dat");

		if(nwrote != datlen)
			die("WriteFile(): couldn't write all of data, %u/%u", nwrote, datlen);
	}
}

//
BYTE * read_req(HANDLE cpipe, req_hdr_t *hdr)
{
	BYTE	*dat;
	DWORD	nread, tmp, nwant;

	if(!ReadFile(cpipe, &hdr->len, sizeof(hdr->len), &nread, NULL))
		die("ReadFile(): req len");

	if(!ReadFile(cpipe, &hdr->op, 1, &nread, NULL))
		die("ReadFile(): req op");
	
	if((unsigned)hdr->op >= sizeof(cops)/sizeof(cops[0]))
		die("Op too big, %u", hdr->op);
		
	info("\n[*]Client req (%d) <%s on pipe %p>, %d (%#x) bytes\n",
						hdr->op, cops[hdr->op], cpipe, hdr->len-1, hdr->len-1);

	dat = (BYTE *)malloc(hdr->len - 1);
	if(dat == NULL)
		die("malloc(%u)", hdr->len - 1);

	nwant = hdr->len - 1;
	nread = 0;

	do{
		if(!ReadFile(cpipe, dat + nread, nwant - nread, &tmp, NULL))
			die("ReadFile(): data");
		nread += tmp;
	}while(nread != nwant);

	hexdump((unsigned char *)dat, hdr->len - 1, 0);

	return dat;
}

// ucs/txt
int file_type = 2;

//
BOOL send_xml_msg(HANDLE pipe, char *file, BYTE **fcontents, DWORD *flen)
{
	int	n, transid, file_len;
	char	*sum, *fname, rbuf[0x1000];
	struct _stat	statbuf;
	FILE	*fp;
	static char	test_msg[0x100];
	BYTE	*buf;

	//for testing, just send a short message
	if(file == NULL){

		//generate random suffix so we dont use a cached version
		memset(test_msg, 0, sizeof(test_msg));
		memset(test_msg, 'A', 100);
		sprintf_s(test_msg + 100, sizeof(test_msg) - 100, "%u%u%u", rand(), rand(), rand());

		sum = MDString(test_msg);
		file_len = (int)strlen(test_msg);
		fname = "test.txt";

		//set output parameters
		*fcontents = (BYTE *)test_msg;
		*flen = file_len;
	}else{
		//send an actual file
		if(_stat(file, &statbuf) != 0)
			die("stat");

		//
		sum = MDFile(file);
		file_len = statbuf.st_size;
		fname = file;

		buf = (BYTE *)malloc(file_len);
		if(buf == NULL)
			die("malloc(%u)", file_len);

		fp = fopen(file, "rb");
		if(fp == NULL)
			die("fopen");

		if(fread(buf, 1, file_len, fp) != file_len)
			die("fread");
		fclose(fp);

		*fcontents = buf;
		*flen = file_len;
	}

	transid = rand();

	n = sprintf_s(rbuf, sizeof(rbuf), xml_msg,
			//filesize, format, md5, doc name, procid, transid
			file_len, file_type, sum, fname, ppt_procid, transid
			);

	info("[o]Sending client XML message:\n\n[%s]\n\n", rbuf);

	write_req(pipe, SRV_SEND_XML, rbuf, n);

	return TRUE;
}

/*
 */
int main(int ac, char **av)
{
	HANDLE	cpipe, tpipe, cur_pipe;
	char	cpipename[0x100],	tpipename[0x100];
	int		state;
	req_hdr_t	hdr;
	DWORD	file_len;
	BYTE	*dat, *file_contents;
	char	*file = NULL;

	//
	if(ac > 1)
		file = av[1];
	if(ac > 2)
		file_type = atoi(av[2]);

	setbuf(stdout, NULL);
	srand((unsigned int)time(0));

	//create the pipes
	sprintf_s(cpipename, "%s%d", CONTROL_PIPE_NAME, PIPE_NUM);
	sprintf_s(tpipename,"%s%d", TRANSFER_PIPE_NAME, PIPE_NUM);

	cpipe = create_pipe(cpipename);
	tpipe = create_pipe(tpipename);
	connect_pipe(cpipe);

	state = WAIT_FOR_CLIENT;
	cur_pipe = cpipe;

	//enter state machine
	while( state != DONE && (dat = read_req(cur_pipe, &hdr)) ){		
		//
		switch(state){
			case WAIT_FOR_CLIENT:
				//send them the name of the transfer pipe
				write_req(cpipe, SERVER_SEND_TPIPENAME, tpipename, (DWORD)strlen(tpipename));
				state = WAIT_FOR_TRANSPIPE_CONNECTION;
				break;
			case WAIT_FOR_TRANSPIPE_CONNECTION:
				connect_pipe(tpipe);
				send_xml_msg(tpipe, file, &file_contents, &file_len);
				state = SENT_XML;
				cur_pipe = tpipe;
				break;
			case SENT_XML:
				//getchar();
				write_req(tpipe, SRV_SEND_FILE, file_contents, file_len);
				state = SENT_FILE;
				break;
			case SENT_FILE:
				if(dat[0] == CONVERSION_SUCCESSFUL){
					info("[o]Conversion successful, data being sent\n");
					state = RECV_CONVERTED_FILE;
				}else if(dat[0] == CONVERSION_FAILED){
					die("[!!]Conversion failed!\n");
				}
				break;
			case RECV_CONVERTED_FILE:
				info("[o]Done with conversion\n");
				state = DONE;
				break;
			default:
				info("WTF!! unknown state %d\n", state);
				exit(1);
				break;
		}
	}

	//cleanup and exit
	DisconnectNamedPipe(cpipe);
	DisconnectNamedPipe(tpipe);
	CloseHandle(cpipe);
	CloseHandle(tpipe);

	return 0;
}