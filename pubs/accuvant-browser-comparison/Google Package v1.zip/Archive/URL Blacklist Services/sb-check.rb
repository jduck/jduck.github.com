#!/usr/bin/ruby

require "uri"
require "net/http"
require "net/https"

while a = gets

params = {'&client=' => 'accu-malwarecheck', 
'&apikey=' => 'ABQIAAAA0U-_72_wxQuzQr-uNew0RxRMzaZd0gqV8PQVpc3HwcG5Wmzzig', 
'appver=' => '0.1', 
'&pver=' => '3.0'
}

#sleep 1

url = URI.escape("#{a}")

http = Net::HTTP.new('sb-ssl.google.com', 443)
http.use_ssl = true
http.verify_mode = OpenSSL::SSL::VERIFY_NONE
#http.set_debug_output $stderr

request = Net::HTTP::Get.new('/safebrowsing/api/lookup?' +"#{params}" +'&url=' +"#{url}")
response = http.request(request)

puts "#{response.code} | #{response.body} | #{url}"

end

