#!/usr/bin/env ruby

require 'watir'
  
ie = Watir::IE.new


  while a = gets
    ie.speed = :zippy
    puts "loading #{a}"
    ie.goto "#{a}"
    sleep 2
    puts "#{ie.url} | #{ie.title} | #{a}"
    ie.close
  end


