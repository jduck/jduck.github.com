#!/usr/bin/env ruby

require 'win32ole'
  
wsh = WIN32OLE.new('Wscript.Shell')

wsh.AppActivate("Security Alert") #Focuses on the pop up window
wsh.SendKeys("%{F4}") #Sends the alt-F4 command to the window to close it

#wsh.AppActivate("403 Forbidden - Windows Internet Explorer") #Focuses on the pop up window
#wsh.SendKeys("%{F4}") #Sends the alt-F4 command to the window to close it
#wsh.AppActivate("404 Not Found - Windows Internet Explorer") #Focuses on the pop up window
#wsh.SendKeys("%{F4}") #Sends the alt-F4 command to the window to close it
#wsh.AppActivate("HTTP 403 Forbidden - Windows Internet Explorer") #Focuses on the pop up window
#wsh.SendKeys("%{F4}") #Sends the alt-F4 command to the window to close it
#wsh.AppActivate("HTTP 404 Not Found - Windows Internet Explorer") #Focuses on the pop up window
#wsh.SendKeys("%{F4}") #Sends the alt-F4 command to the window to close it

#wsh.AppActivate("Internet Explorer cannot display the webpage - Windows Internet Explorer")
#wsh.SendKeys("%{F4}") #Sends the alt-F4 command to the window to close it
#wsh.AppActivate("Internet Explorer cannot display the webpage - Windows Internet Explorer")
#wsh.SendKeys("%{F4}") #Sends the alt-F4 command to the window to close it

