// PocRunLoader.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define LIBRARY "pocdll.dll"
#define FUNC "Run"
#define OUTPUT L"%USERPROFILE%\\AppData\\LocalLow\\output.txt"

typedef void(__cdecl *lpfnInit)(HANDLE);

int _tmain(int argc, _TCHAR* argv[])
{
	HMODULE dll_mod = ::LoadLibraryA(LIBRARY);
	if (dll_mod == NULL)
	{
		printf("[ERROR] Could not load %s\r\n", LIBRARY);
		exit(1);
	}

	lpfnInit run_func = (lpfnInit) ::GetProcAddress(dll_mod, FUNC);
	if (run_func == NULL)
	{
		printf("[ERROR] Could not run %s::%s\r\n", LIBRARY, FUNC);
		exit(1);
	}

	WCHAR path_expanded[MAX_PATH] = {0};
	DWORD size = ExpandEnvironmentStringsW(OUTPUT, path_expanded, MAX_PATH-1);
	if(!size)
	{
		printf("[ERROR] Could not expand %ls\r\n", OUTPUT);
		exit(1);
	}
    HANDLE pipe = ::CreateFile(path_expanded, 
							   GENERIC_WRITE,
                               FILE_SHARE_READ | FILE_SHARE_WRITE,
                               NULL,  // Default security attributes.
                               CREATE_ALWAYS,
                               FILE_ATTRIBUTE_NORMAL,
                               NULL);  // No template

    if (INVALID_HANDLE_VALUE == pipe) {
      printf("[ERROR] Could not open %ls\r\n", OUTPUT);
	  exit(1);
    }

	run_func(pipe);
	CloseHandle(pipe);
	::FreeLibrary(dll_mod);

	return 0;
}

