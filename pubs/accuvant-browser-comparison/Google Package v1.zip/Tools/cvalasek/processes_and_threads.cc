// Copyright (c) 2006-2008 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <windows.h>
#include <Tlhelp32.h>
#include "sandbox/sandbox_poc/pocdll/exports.h"
#include "sandbox/sandbox_poc/pocdll/utils.h"

// This file contains the tests used to verify the security of threads and
// processes.

void POCDLL_API TestProcesses(HANDLE log) {
  HandleToFile handle2file;
  FILE *output = handle2file.Translate(log, "w");

  HANDLE snapshot = ::CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
  if (INVALID_HANDLE_VALUE == snapshot) {
    fprintf(output, "[BLOCKED] Cannot list all processes on the system. "
                    "Error %d\r\n", ::GetLastError());
    return;
  }

  PROCESSENTRY32 process_entry = {0};
  process_entry.dwSize = sizeof(PROCESSENTRY32);

  BOOL result = ::Process32First(snapshot, &process_entry);

  while (result) {
	// Do not inherit handle.
    HANDLE process = ::OpenProcess(PROCESS_VM_READ, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_VM_READ} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_VM_READ} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_DUP_HANDLE, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_DUP_HANDLE} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_DUP_HANDLE} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_QUERY_INFORMATION} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_QUERY_INFORMATION} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_QUERY_LIMITED_INFORMATION} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_QUERY_LIMITED_INFORMATION} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_SET_INFORMATION, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_SET_INFORMATION} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_SET_INFORMATION} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_SET_QUOTA, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_SET_QUOTA} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_SET_QUOTA} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_SUSPEND_RESUME, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_SUSPEND_RESUME} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_SUSPEND_RESUME} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_TERMINATE, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_TERMINATE} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_TERMINATE} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_VM_OPERATION, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_VM_OPERATION} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_VM_OPERATION} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(PROCESS_VM_WRITE, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {PROCESS_VM_WRITE} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {PROCESS_VM_WRITE} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(SYNCHRONIZE, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {SYNCHRONIZE} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {SYNCHRONIZE} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(WRITE_DAC, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {WRITE_DAC} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {WRITE_DAC} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(READ_CONTROL, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {READ_CONTROL} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {READ_CONTROL} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

	/////////////////////////////////////////////////
	process = ::OpenProcess(WRITE_OWNER, FALSE, process_entry.th32ProcessID);
    if (NULL == process) 
	{
		fprintf(output, "[BLOCKED] {WRITE_OWNER} Found process %S:%d but cannot open it. "
                      "Error %d\r\n",
                      process_entry.szExeFile,
                      process_entry.th32ProcessID,
                      ::GetLastError());
    } 
	else 
	{
		fprintf(output, "[GRANTED] {WRITE_OWNER} Found process %S:%d and open succeeded.\r\n",
                      process_entry.szExeFile, process_entry.th32ProcessID);
      ::CloseHandle(process);
    }

    result = ::Process32Next(snapshot, &process_entry);
  
  }

  DWORD err_code = ::GetLastError();
  if (ERROR_NO_MORE_FILES != err_code) {
    fprintf(output, "[ERROR] Error %d while looking at the processes on "
                    "the system\r\n", err_code);
  }

  ::CloseHandle(snapshot);

	//CV - Attempt to spawn a new child process
	STARTUPINFOW si;
	PROCESS_INFORMATION pi;
	WCHAR wszProcess_Sys[MAX_PATH] = L"C:\\Program Files\\Internet Explorer\\iexplore.exe";
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	ZeroMemory(&pi, sizeof(pi));

	if (!CreateProcessW(NULL, wszProcess_Sys, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
	{
		fprintf(output, "[BLOCKED] CreateProcess[%ls] -> Error: %d\r\n", wszProcess_Sys, GetLastError());
	}
	else
	{
		fprintf(output, "[GRANTED] CreateProcess[%ls]\r\n", wszProcess_Sys);
		if(!TerminateProcess(pi.hProcess, 0))
			fprintf(output, "[ERROR] Terminate Procces -> Error: %d\r\n", GetLastError());
	}

}

void POCDLL_API TestThreads(HANDLE log) {
  HandleToFile handle2file;
  FILE *output = handle2file.Translate(log, "w");

  HANDLE snapshot = ::CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, NULL);
  if (INVALID_HANDLE_VALUE == snapshot) {
    fprintf(output, "[BLOCKED] Cannot list all threads on the system. "
                    "Error %d\r\n", ::GetLastError());
    return;
  }

  THREADENTRY32 thread_entry = {0};
  thread_entry.dwSize = sizeof(THREADENTRY32);

  BOOL result = ::Thread32First(snapshot, &thread_entry);
  int nb_success = 0;
  int nb_failure = 0;

  while (result) {
	
	// Do not inherit handles.
    HANDLE thread = ::OpenThread(THREAD_QUERY_INFORMATION, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_QUERY_INFORMATION} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_QUERY_INFORMATION} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(SYNCHRONIZE, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {SYNCHRONIZE} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {SYNCHRONIZE} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_DIRECT_IMPERSONATION, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_DIRECT_IMPERSONATION} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_DIRECT_IMPERSONATION} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_GET_CONTEXT, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_GET_CONTEXT} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_GET_CONTEXT} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_IMPERSONATE, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_IMPERSONATE} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_IMPERSONATE} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_QUERY_LIMITED_INFORMATION, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_QUERY_LIMITED_INFORMATION} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_QUERY_LIMITED_INFORMATION} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_SET_CONTEXT, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_SET_CONTEXT} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_SET_CONTEXT} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_SET_INFORMATION, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_SET_INFORMATION} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_SET_INFORMATION} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_SET_LIMITED_INFORMATION, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_SET_LIMITED_INFORMATION} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_SET_LIMITED_INFORMATION} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_SET_THREAD_TOKEN, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_SET_THREAD_TOKEN} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_SET_THREAD_TOKEN} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_SUSPEND_RESUME, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_SUSPEND_RESUME} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_SUSPEND_RESUME} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(THREAD_TERMINATE, FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {THREAD_TERMINATE} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {THREAD_TERMINATE} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(READ_CONTROL , FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {READ_CONTROL} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {READ_CONTROL} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(WRITE_DAC , FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {WRITE_DAC} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {WRITE_DAC} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

	//////////////////////////////////////////////////////
	thread = ::OpenThread(WRITE_OWNER , FALSE, thread_entry.th32ThreadID);
    if (NULL == thread) {
      nb_failure++;
	  fprintf(output, "[BLOCKED] {WRITE_OWNER} Thread %d:%d was inaccessible Error: %X\r\n", thread_entry.th32OwnerProcessID, thread_entry.th32ThreadID, GetLastError());
    } 
	else {
      nb_success++;
      fprintf(output, "[GRANTED] {WRITE_OWNER} Found thread %d:%d and able to open it.\r\n",
                      thread_entry.th32OwnerProcessID,
                      thread_entry.th32ThreadID);
      ::CloseHandle(thread);
    }

    result = Thread32Next(snapshot, &thread_entry);
  }

  DWORD err_code = ::GetLastError();
  if (ERROR_NO_MORE_FILES != err_code) {
    fprintf(output, "[ERROR] Error %d while looking at the processes on "
                    "the system\r\n", err_code);
  }

  fprintf(output, "[INFO] Found %d threads. Able to open %d of them\r\n",
          nb_success + nb_failure, nb_success);

  ::CloseHandle(snapshot);
}
