#!/bin/bash
# Just a quick utility to kill IE processes if they use more than a set amount of RAM during automation
# At that point the process has already rendered the page or it wouldn't be hung, and we're looking 
# specifically for the "Unsafe" status bar line to see if a page was caught by URS.

while true 
do 
 tasklist /FI "IMAGENAME eq iexplore.exe" /v | grep '[3-9][2-9],[0-9,3]'| awk -F " "  '{print $2}' | head -1 | xargs taskkill /F /PID 
 sleep 20s 
 cat ieresults-0*.csv | wc -l ; cat ieresults-0*.csv | grep Unsafe | wc -l
done
